<?php
return [
	'general_title'		=> 'My Doctor Finder'
];