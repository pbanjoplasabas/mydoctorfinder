

	<div class="container">
		<div class="row">
			<div class="col-sm-6">
				<div class="search-home">
					<h1 class="search-title">Find Doctors</h1>
					<p class="search-sub-title md-padding-bottom md-margin-bottom">Bridging doctors and patients efficiently</p>
					<form role="form">
						<div class="form-group">
							<select class="search-default" name="specialty" id="specialty-id" placeholder="Select Specialty">
								<option disabled selected>Select Specialty</option>
								<?php foreach($specialties as $specialty): ?>
								<option value="<?php echo e($specialty->id); ?>"><?php echo e($specialty->specialization); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						<div class="form-group">
							<select class="search-default" name="location" id="location-id" placeholder="Select Location">
								<option disabled selected>Select Location</option>
								<?php foreach($locations as $location): ?>
								<option value="<?php echo e($location->location_name); ?>"><?php echo e($location->location_name); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						<div class="form-group">
							<button type="submit" class="btn btn-theme btn-100">
								Find Doctors
							</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>	
	

	<script type="text/javascript">
		$(document).ready(function() {
			// Populate selectize field with categories
			$('.search-default').selectize();
		});
	</script>