<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo e((isset($title) ? $title : 'My Doctor Finder')); ?></title>
	<link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('jasny-bootstrap/css/jasny-bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('font-awesome/css/font-awesome.min.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">

	<script type="text/javascript" src="<?php echo e(asset('js/jquery-1.11.3.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/jquery-ui/jquery-ui.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('jasny-bootstrap/js/jasny-bootstrap.min.js')); ?>"></script>

	<?php /* Selectize Plugin */ ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('selectize/css/selectize.css')); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('selectize/css/selectize.default.css')); ?>" />
	<script type="text/javascript" src="<?php echo e(asset('selectize/js/selectize.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('selectize/js/standalone/selectize.js')); ?>"></script>

	<?php /* Javascript for google maps APIv3 */ ?>
	<script src="https://maps.googleapis.com/maps/api/js"></script>
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>

	<?php echo $__env->make('layout.header-main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->make('layout.map-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->yieldContent('content'); ?>

</body>
</html>