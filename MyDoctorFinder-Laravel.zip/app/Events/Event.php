<?php

namespace MyDoctorFinder\Events;

abstract class Event
{
    //
}
