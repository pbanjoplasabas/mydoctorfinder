<?php

namespace MyDoctorFinder\Libraries;

# Import Library namespaces
use DB;

class LocationLoader
{


	public static function display($id = 0)
	{
		
	}


}