<?php

namespace MyDoctorFinder;

use Illuminate\Database\Eloquent\Model;
# Import Library namespaces
use DB;

class Doctors extends Model
{

	/**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'doctors';

    /** 
	 * Method used to retrieve the doctors list
     *
     * @param float : $latitude
     * @param float : $longitude
     * @param integer : $start
     * @param integer : $limit
     * @param array : $query
     * @return Collection
     */
    public function getDoctorsList($latitude = 0, $longitude = 0, $start = 0, $limit = 25, $query = array())
    {
        // $this->data     = DB::table('doctors')
        //                     ->leftJoin('doctors_details AS dhospital', 'doctors.id', '=', 'dhospital.doctor_id')
        //                     ->leftJoin('listing_hospitals', 'doctors.id', '=', 'listing_hospitals.id')
        //                     ->leftJoin('doctors_details AS dhmo', 'dhospital.detail_id', '=', 'dhmo.doctor_id')
        //                     ->leftJoin('listing_hmo', 'dhmo.detail_id', '=', 'listing_hmo.id')
        //                     ->select(array('doctors.*','dhospital.detail_id as hospital_id', 'listing_hospitals.listing_title as hospital_title', 'dhmo.detail_id as hmo_id', 'listing_hmo.listing_title as hmo_title'))
        //                     ->where('dhospital.detail_type', '=', 1)
        //                     ->where('dhmo.detail_type', '=', 4)
        //                     ->groupBy('doctors.id')
        //                     ->take($limit)
        //                     ->get();

        // $this->data     = DB::select(DB::raw('SELECT doctors.*, dhospital.detail_id as hospital_id, listing_hospitals.listing_title as hospital_title, dhmo.detail_id as hmo_id, listing_hmo.listing_title as hmo_title FROM doctors LEFT JOIN doctors_details dhospital ON doctors.id = dhospital.doctor_id LEFT JOIN listing_hospitals ON dhospital.detail_id = listing_hospitals.id LEFT JOIN doctors_details dhmo ON doctors.id = dhmo.doctor_id LEFT JOIN listing_hmo ON dhmo.detail_id = listing_hmo.id WHERE dhospital.detail_type = 1 AND dhmo.detail_type = 4 GROUP BY doctors.id LIMIT 5'));
    	$this->data     = DB::select(DB::raw('SELECT doctors.*, dhospital.detail_id as hospital_id, listing_hospitals.listing_title as hospital_title, listing_hospitals.latitude, listing_hospitals.longitude, listing_hospitals.street, location_cities.city_name, location_provinces.province_name, dhmo.detail_id as hmo_id, listing_hmo.listing_title as hmo_title, (6371 * acos (cos ( radians('.$latitude.') ) * cos( radians( listing_hospitals.latitude ) ) * cos( radians( listing_hospitals.longitude ) - radians('.$longitude.') ) + sin ( radians('.$latitude.') ) * sin( radians( listing_hospitals.latitude ) ))) AS distance FROM doctors LEFT JOIN doctors_details dhospital ON doctors.id = dhospital.doctor_id LEFT JOIN listing_hospitals ON dhospital.detail_id = listing_hospitals.id LEFT JOIN doctors_details dhmo ON doctors.id = dhmo.doctor_id LEFT JOIN listing_hmo ON dhmo.detail_id = listing_hmo.id LEFT JOIN location_cities ON location_cities.id = listing_hospitals.city LEFT JOIN location_provinces ON location_provinces.id = listing_hospitals.province WHERE dhospital.detail_type = 1 AND dhmo.detail_type = 4 GROUP BY doctors.id HAVING distance > 25  LIMIT 25'));
        return $this->data;
    }

}
